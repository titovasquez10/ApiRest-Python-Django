from django.apps import AppConfig


class ApipicoConfig(AppConfig):
    name = 'apiPico'
