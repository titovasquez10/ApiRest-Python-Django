from django.apps import AppConfig


class PicoplacaappConfig(AppConfig):
    name = 'PicoplacaApp'
